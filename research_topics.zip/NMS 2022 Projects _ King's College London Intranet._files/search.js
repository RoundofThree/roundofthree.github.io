$(function () {

    /*Get default search boc values*/
    var ihDefaultText = $('#header input#MainSearchQueryControl_SearchTextBox').val();
    var phDefaultText = $('#header input#TextboxWithRedirect_redirectTextBox').val();


    var iqlDefaultText = $('.sys_quick_links input#quickLinksSearchQueryControl_SearchTextBox').val();
    var pqlDefaultText = $('.sys_quick_links input#TextboxWithRedirect_redirectTextBox').val();

    /*Header site search click*/
    $('#header input#mainSearchIntranet').click(function () {
        /*Show main search hide people search*/
        $('#header .sys_search-query-control').show()
        $('#header .sys_textBoxWithRedirect').hide()

        /*If people search text as changed then set main search to be the same*/
        if ($('#header input#TextboxWithRedirect_redirectTextBox').val() != phDefaultText) {
            $('#header input#MainSearchQueryControl_SearchTextBox').val($('#header input#TextboxWithRedirect_redirectTextBox').val())
        }
    });

    /*Header people search click*/
    $('#header input#mainSearchPeople').click(function () {
        /*Show people search hide main search*/
        $('#header .sys_search-query-control').hide()
        $('#header .sys_textBoxWithRedirect').show()

        /*If main search text as changed then set people search to be the same*/
        if ($('#header input#MainSearchQueryControl_SearchTextBox').val() != ihDefaultText) {
            $('#header input#TextboxWithRedirect_redirectTextBox').val($('#header input#MainSearchQueryControl_SearchTextBox').val())
        }
    });

    /*Quick links site search click*/
    $('.sys_quick_links input#quickSearchIntranet').click(function () {
        /*Show main search hide people search*/
        $('.sys_quick_links .sys_search-query-control').show()
        $('.sys_quick_links .sys_textBoxWithRedirect').hide()

        /*If people search text as changed then set main search to be the same*/
        if ($('.sys_quick_links input#quickLinksTextboxWithRedirect_redirectTextBox').val() != pqlDefaultText) {
            $('.sys_quick_links input#quickLinksSearchQueryControl_SearchTextBox').val($('.sys_quick_links input#quickLinksTextboxWithRedirect_redirectTextBox').val())
        }
    });

    /*Quick links people search click*/
    $('.sys_quick_links input#quickSearchPeople').click(function () {
        /*Show people search hide main search*/
        $('.sys_quick_links .sys_search-query-control').hide()
        $('.sys_quick_links .sys_textBoxWithRedirect').show()

        /*If main search text as changed then set people search to be the same*/
        if ($('.sys_quick_links input#quickLinksSearchQueryControl_SearchTextBox').val() != iqlDefaultText) {
            $('.sys_quick_links input#quickLinksTextboxWithRedirect_redirectTextBox').val($('.sys_quick_links input#quickLinksSearchQueryControl_SearchTextBox').val())
        }
    });
       
});