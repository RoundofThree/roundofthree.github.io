// JavaScript Document
//Expaning text within a page - IKM 14 Mar 2011
$(document).ready(function(){
	$(".sys_toggle_container").hide();
	$(".sys_trigger").click(function(){
		$(this).toggleClass("active").next().slideToggle("slow");
		});
	});