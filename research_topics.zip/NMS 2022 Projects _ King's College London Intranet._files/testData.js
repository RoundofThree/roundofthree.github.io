var testData = {};
	
// The object that the JSON string should represent, can use this as it is if you want.
testData.webSites = [
	{
		id: 1,
		text: 'Common Rooms'
	},
	{
		id: 2,
		text: 'Arts & Humanities'
	},
	{
		id: 3,
		text: 'Human Resources'
	},
	{
		id: 4,
		text: 'Teaching Support'
	},
	{
		id: 5,
		text: 'Medicine'
	},
	{
		id: 6,
		text: 'Dental'
	},
	{
		id: 7,
		text: 'IT Services'
	},
	{
		id: 8,
		text: 'Religion'
	}
	
	];
	
